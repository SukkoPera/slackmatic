/* Dummy C program; we use this in the package build process to construct a
 * proper shlibs file for libfakeroot 
 */
int main(void) {
	return(0);	
}
